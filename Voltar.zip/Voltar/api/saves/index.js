import { sql } from '../../lib/db.js';
import { getSession } from '../../lib/session.js';

export default async function handler(req, res) {
  const session = await getSession(req, res);
  if (!session.user) return res.status(401).json({ error: 'Not authenticated' });

  const userId = session.user.id;

  if (req.method === 'GET') {
    const result = await sql`
      SELECT * FROM saves WHERE user_id = ${userId}
      ORDER BY created_at DESC LIMIT 50
    `;
    return res.json({ saves: result.rows });
  }

  if (req.method === 'POST') {
    const { name, executor = 'Voltar v3.2' } = req.body;
    if (!name || name.length < 2) return res.status(400).json({ error: 'Name required' });

    // Slot-Nummer automatisch
    const countRes = await sql`SELECT COUNT(*) as c FROM saves WHERE user_id = ${userId}`;
    const slot = (parseInt(countRes.rows[0].c) + 1).toString().padStart(2, '0');

    const result = await sql`
      INSERT INTO saves (user_id, name, executor, slot)
      VALUES (${userId}, ${name}, ${executor}, ${slot})
      RETURNING *
    `;
    return res.status(201).json({ save: result.rows[0] });
  }

  res.status(405).json({ error: 'Method not allowed' });
}