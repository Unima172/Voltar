import { sql } from '../lib/db.js';
import { getSession } from '../lib/session.js';

const EXECS = ['Voltar v3.2', 'Voltar v3.1', 'Synapse Z', 'Delta V5', 'Krnl V2', 'Fluxus', 'Wave V3', 'Solara'];
const randHex = n => [...Array(n)].map(() => '0123456789ABCDEF'[Math.random()*16|0]).join('');

export default async function handler(req, res) {
  if (req.method !== 'POST') return res.status(405).json({ error: 'Method not allowed' });

  const session = await getSession(req, res);
  if (!session.user) return res.status(401).json({ error: 'Not authenticated' });

  const { scriptName } = req.body;
  if (!scriptName) return res.status(400).json({ error: 'scriptName required' });

  // Detect executor
  const isV = /voltar/i.test(scriptName);
  const executor = isV ? 'Voltar v3.2' : EXECS[Math.floor(Math.random() * EXECS.length)];
  const confidence = (isV ? 97 + Math.random() * 2.9 : 88 + Math.random() * 10).toFixed(1);
  const vmSig = 'VM-' + randHex(4) + '-' + randHex(4) + '-' + randHex(4);
  const hwidFrag = randHex(4) + '···' + randHex(4);
  const saveHash = 'sha256:' + randHex(16).toLowerCase() + '…';
  const status = isV ? 'verified' : 'foreign_signature';

  // Persist log
  const result = await sql`
    INSERT INTO executor_logs (user_id, executor, script_name, confidence, vm_signature, hwid_fragment, save_hash, status)
    VALUES (${session.user.id}, ${executor}, ${scriptName}, ${confidence}, ${vmSig}, ${hwidFrag}, ${saveHash}, ${status})
    RETURNING *
  `;

  res.json({ log: result.rows[0] });
}