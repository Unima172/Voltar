import { sql } from '@vercel/postgres';

async function setup() {
  console.log('🔧 Creating tables...');

  await sql`
    CREATE TABLE IF NOT EXISTS users (
      id SERIAL PRIMARY KEY,
      username VARCHAR(50) UNIQUE NOT NULL,
      email VARCHAR(255) UNIQUE NOT NULL,
      password_hash VARCHAR(255) NOT NULL,
      hwid VARCHAR(64),
      is_premium BOOLEAN DEFAULT false,
      created_at TIMESTAMP DEFAULT NOW()
    )
  `;
  console.log('✓ users table');

  await sql`
    CREATE TABLE IF NOT EXISTS saves (
      id SERIAL PRIMARY KEY,
      user_id INTEGER REFERENCES users(id) ON DELETE CASCADE,
      name VARCHAR(100) NOT NULL,
      executor VARCHAR(50),
      version VARCHAR(20) DEFAULT '3.2.1',
      slot INTEGER,
      created_at TIMESTAMP DEFAULT NOW()
    )
  `;
  console.log('✓ saves table');

  await sql`
    CREATE TABLE IF NOT EXISTS executor_logs (
      id SERIAL PRIMARY KEY,
      user_id INTEGER REFERENCES users(id) ON DELETE CASCADE,
      executor VARCHAR(100) NOT NULL,
      script_name VARCHAR(200),
      confidence DECIMAL(5,2),
      vm_signature VARCHAR(40),
      hwid_fragment VARCHAR(16),
      save_hash VARCHAR(64),
      status VARCHAR(30) DEFAULT 'verified',
      scanned_at TIMESTAMP DEFAULT NOW()
    )
  `;
  console.log('✓ executor_logs table');

  await sql`
    CREATE INDEX IF NOT EXISTS idx_saves_user ON saves(user_id)
  `;
  await sql`
    CREATE INDEX IF NOT EXISTS idx_logs_user ON executor_logs(user_id)
  `;
  console.log('✓ indexes');

  console.log('\n🎉 Database ready!');
  process.exit(0);
}

setup().catch(err => {
  console.error('❌ Setup failed:', err);
  process.exit(1);
});