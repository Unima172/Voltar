import { sql } from '../lib/db.js';
import { getSession } from '../lib/session.js';

export default async function handler(req, res) {
  const session = await getSession(req, res);
  if (!session.user) return res.status(401).json({ error: 'Not authenticated' });

  const result = await sql`
    SELECT * FROM executor_logs WHERE user_id = ${session.user.id}
    ORDER BY scanned_at DESC LIMIT 30
  `;
  res.json({ logs: result.rows });
}