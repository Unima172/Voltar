import { sql } from '../../lib/db.js';
import { getSession } from '../../lib/session.js';
import bcrypt from 'bcryptjs';
import { z } from 'zod';

const schema = z.object({
  username: z.string().min(3).max(30).regex(/^[a-zA-Z0-9_]+$/),
  email: z.string().email(),
  password: z.string().min(8),
});

export default async function handler(req, res) {
  if (req.method !== 'POST') return res.status(405).json({ error: 'Method not allowed' });

  try {
    const { username, email, password } = schema.parse(req.body);

    // Check existing user
    const existing = await sql`
      SELECT id FROM users WHERE email = ${email} OR username = ${username}
    `;
    if (existing.rows.length > 0) {
      return res.status(409).json({ error: 'Email or username already taken' });
    }

    const hash = await bcrypt.hash(password, 12);
    const result = await sql`
      INSERT INTO users (username, email, password_hash)
      VALUES (${username}, ${email}, ${hash})
      RETURNING id, username, email
    `;

    const user = result.rows[0];
    const session = await getSession(req, res);
    session.user = { id: user.id, username: user.username, email: user.email };
    await session.save();

    res.status(201).json({ user: { id: user.id, username: user.username, email: user.email } });
  } catch (err) {
    if (err instanceof z.ZodError) {
      return res.status(400).json({ error: err.errors[0].message });
    }
    console.error('Register error:', err);
    res.status(500).json({ error: 'Registration failed' });
  }
}