import { sql } from '../../lib/db.js';
import { getSession } from '../../lib/session.js';

export default async function handler(req, res) {
  const session = await getSession(req, res);
  if (!session.user) return res.status(401).json({ error: 'Not authenticated' });

  const { id } = req.query;

  if (req.method === 'DELETE') {
    await sql`
      DELETE FROM saves WHERE id = ${id} AND user_id = ${session.user.id}
    `;
    return res.json({ ok: true });
  }

  res.status(405).json({ error: 'Method not allowed' });
}